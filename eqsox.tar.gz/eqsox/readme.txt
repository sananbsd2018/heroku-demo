eQSOx Server daemon
Release Version 2.01a

To launch, first chomd (u+x) then run the daemon binary.

For info, help and the latest builds please see www.ham.eqsox.org

Please report bugs and strange goings on to eqsox@446user.co.uk

eQSO is (c) Paul M0ZPD
eQSOx is (c) Dean M3DPE and is based on Paul's original eQSO protocol.

Many thanks to Paul for letting have that and letting me build this.

If you redistribute this archive please keep this readme file in tact.

Dean
29th August 2004
